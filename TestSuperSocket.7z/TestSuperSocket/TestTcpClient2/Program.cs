﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using SuperSocket.ClientEngine;

namespace TestTcpClient2
{
    class Program
    {
        static EasyClient<MyPackageInfo> client = new EasyClient<MyPackageInfo>();

        static void Main(string[] args)
        {
            client.Initialize(new MyReceiveFilter());
            client.Connected += client_Connected;
            client.Closed += client_Closed;
            client.Error += client_Error;
            client.NewPackageReceived += client_NewPackageReceived;

            var endPoint = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 8123);

            client.ConnectAsync(endPoint);

            
            Console.ReadKey();
        }

        static void client_NewPackageReceived(object sender, PackageEventArgs<MyPackageInfo> e)
        {
            

            Console.WriteLine("NewPackageReceived");
            try
            {
                Console.WriteLine(e.Package.Body);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }


        }

        static void client_Error(object sender, ErrorEventArgs e)
        {
            Console.WriteLine("Error");
        }

        static void client_Closed(object sender, EventArgs e)
        {
            Console.WriteLine("Closed");
        }

        static void client_Connected(object sender, EventArgs e)
        {
            client.Send(GetFixedHeaderBytes("你好我是客户端"));
            Console.WriteLine("Connected");
        }


        private static byte[] GetFixedHeaderBytes(string data)
        {
            var dataBytes = Encoding.UTF8.GetBytes(data);
            var headBytes = BitConverter.GetBytes(dataBytes.Length).Reverse();

            var allBytes = new List<byte>();
            allBytes.AddRange(headBytes);
            allBytes.AddRange(dataBytes);
            return allBytes.ToArray();
        }
        
    }
}
