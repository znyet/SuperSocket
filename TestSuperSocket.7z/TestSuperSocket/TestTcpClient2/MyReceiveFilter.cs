﻿using System;
using System.Linq;
using SuperSocket.ProtoBase;

namespace TestTcpClient2
{
    class MyReceiveFilter : FixedHeaderReceiveFilter<MyPackageInfo>
    {
        public MyReceiveFilter()
            : base(4)
        {

        }

        protected override int GetBodyLengthFromHeader(IBufferStream bufferStream, int length)
        {
            var buffers = bufferStream.Buffers[0];
            var headBytes = buffers.Array.CloneRange(buffers.Offset, buffers.Count);

            int len = BitConverter.ToInt32(headBytes.Reverse().ToArray(), 0);
            return len;
        }

        public override MyPackageInfo ResolvePackage(IBufferStream bufferStream)
        {
            var headBuffer = bufferStream.Buffers[0];
            var bodyBuffer = bufferStream.Buffers[1];

            var headBytes = headBuffer.Array.CloneRange(headBuffer.Offset, headBuffer.Count);
            var bodyBytes = bodyBuffer.Array.CloneRange(bodyBuffer.Offset, bodyBuffer.Count);

            return new MyPackageInfo(headBytes, bodyBytes);
        }


    }
}



//TerminatorReceiveFilter
//BeginEndMarkReceiveFilter
//FixedHeaderReceiveFilter
//FixedSizeReceiveFilter
//CountSpliterReceiveFilter