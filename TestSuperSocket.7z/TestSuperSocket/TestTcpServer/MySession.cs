﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using SuperSocket.SocketBase;
using SuperSocket.SocketBase.Protocol;

namespace TestTcpServer
{
    public class MySession : AppSession<MySession, BinaryRequestInfo>
    {

        protected override void OnSessionStarted()
        {

            Console.WriteLine("OnSessionStarted");
            base.OnSessionStarted();

            var data = GetFixedHeaderBytes("你好我是服务端");
            Send(data, 0, data.Length);
        }


        protected override void HandleException(Exception e)
        {
            Console.WriteLine("HandleException");
            base.HandleException(e);
        }

        protected override void HandleUnknownRequest(BinaryRequestInfo requestInfo)
        {
            Console.WriteLine("HandleUnknownRequest");
            Console.WriteLine(Encoding.UTF8.GetString(requestInfo.Body));
            base.HandleUnknownRequest(requestInfo);
        }

        protected override void OnSessionClosed(CloseReason reason)
        {
            Console.WriteLine("OnSessionClosed");
            base.OnSessionClosed(reason);
        }

        private static byte[] GetFixedHeaderBytes(string data)
        {
            var dataBytes = Encoding.UTF8.GetBytes(data);
            var headBytes = BitConverter.GetBytes(dataBytes.Length).Reverse();

            var allBytes = new List<byte>();
            allBytes.AddRange(headBytes);
            allBytes.AddRange(dataBytes);
            return allBytes.ToArray();
        }

    }
}
