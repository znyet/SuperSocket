﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Text;
using SuperSocket.Common;
using SuperSocket.Facility.Protocol;
using SuperSocket.SocketBase.Protocol;

namespace TestTcpServer
{


    /// +-----------+-------------------------------+
    /// |           |                               |
    /// |    lenth  |        request body           |
    /// |     4     |                               |
    /// |           |                               |
    /// +-----------+-------------------------------+
    public class MyReceiveFilter : FixedHeaderReceiveFilter<BinaryRequestInfo>
    {
        public MyReceiveFilter()
            : base(4)
        {

        }

        protected override int GetBodyLengthFromHeader(byte[] header, int offset, int length)
        {
            var headBytes = header.CloneRange(offset, length);
            int bodyLength = BitConverter.ToInt32(headBytes.Reverse().ToArray(), 0);
            return bodyLength;
        }

        protected override BinaryRequestInfo ResolveRequestInfo(ArraySegment<byte> header, byte[] bodyBuffer, int offset, int length)
        {
            return new BinaryRequestInfo("", bodyBuffer.CloneRange(offset, length));
        }
    }


    /// +-------+---+-------------------------------+
    /// |request| l |                               |
    /// | name  | e |    request body               |
    /// |  (4)  | n |                               |
    /// |       |(2)|                               |
    /// +-------+---+-------------------------------+
    //public class MyReceiveFilter : FixedHeaderReceiveFilter<BinaryRequestInfo>
    //{
    //    public MyReceiveFilter() : base(6)
    //    {

    //    }

    //    protected override int GetBodyLengthFromHeader(byte[] header, int offset, int length)
    //    {
    //        return (int)header[offset + 4] * 256 + (int)header[offset + 5];
    //    }

    //    protected override BinaryRequestInfo ResolveRequestInfo(ArraySegment<byte> header, byte[] bodyBuffer, int offset, int length)
    //    {
    //        return new BinaryRequestInfo(Encoding.UTF8.GetString(header.Array, header.Offset, 4), bodyBuffer.CloneRange(offset, length));
    //    }
    //}




}
