﻿using SuperSocket.SocketBase;
using SuperSocket.SocketBase.Protocol;

namespace TestTcpServer
{
    class MyServer : AppServer<MySession, BinaryRequestInfo>
    {
        public MyServer()
            : base(new DefaultReceiveFilterFactory<MyReceiveFilter, BinaryRequestInfo>())
        {

        }
    }
}
