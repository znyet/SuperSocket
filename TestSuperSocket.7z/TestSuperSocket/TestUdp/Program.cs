﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SuperSocket.SocketBase;
using SuperSocket.SocketBase.Config;

namespace TestUdp
{
    class Program
    {
        static void Main(string[] args)
        {
            var config = new ServerConfig()
            {
                //Name = "SSServer",
                //ServerTypeName = "SServer",
                ClearIdleSession = true, //60秒执行一次清理90秒没数据传送的连接
                ClearIdleSessionInterval = 60,
                IdleSessionTimeOut = 90,
                MaxRequestLength = 2048, //最大包长度
                Ip = "Any",
                Port = 8123,
                MaxConnectionNumber = 100000,
                Mode = SocketMode.Udp
            };

           

            var server = new AppServer();
            server.NewSessionConnected += server_NewSessionConnected;
            server.SessionClosed += server_SessionClosed;
            server.NewRequestReceived += server_NewRequestReceived;


            server.Setup(config);
            server.Start();
            
            Console.WriteLine("tcp server listen in port:" + 8123);
            Console.ReadKey();
        }

        static void server_NewRequestReceived(AppSession session, SuperSocket.SocketBase.Protocol.StringRequestInfo requestInfo)
        {
            throw new NotImplementedException();
        }

        static void server_SessionClosed(AppSession session, CloseReason value)
        {
            throw new NotImplementedException();
        }

        static void server_NewSessionConnected(AppSession session)
        {
            throw new NotImplementedException();
        }
    }
}
