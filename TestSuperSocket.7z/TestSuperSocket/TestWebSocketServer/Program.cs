﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SuperSocket.SocketBase;
using SuperSocket.SocketBase.Config;
using SuperSocket.WebSocket;

namespace TestWebSocketServer
{
    class Program
    {
        static void Main(string[] args)
        {
            //websocket
            var config = new ServerConfig()
            {
                //Name = "SSServer",
                //ServerTypeName = "SServer",
                ClearIdleSession = true, //60秒执行一次清理90秒没数据传送的连接
                ClearIdleSessionInterval = 60,
                IdleSessionTimeOut = 90,
                MaxRequestLength = 2048, //最大包长度
                Ip = "Any",
                Port = 8124,
                MaxConnectionNumber = 100000,
                Mode = SocketMode.Tcp
            };

            var webscoketServer = new WebSocketServer();
            webscoketServer.SessionClosed += webscoketServer_SessionClosed;
            webscoketServer.NewSessionConnected += webscoketServer_NewSessionConnected;
            webscoketServer.NewDataReceived += webscoketServer_NewDataReceived;
            webscoketServer.NewMessageReceived += webscoketServer_NewMessageReceived;

            webscoketServer.Setup(config);
            webscoketServer.Start();
            Console.WriteLine("webscoket server listen in port:" + 8124);
            Console.ReadKey();

        }

        static void webscoketServer_NewMessageReceived(WebSocketSession session, string value)
        {
            session.Send("我去");
            Console.WriteLine(session.AppServer.SessionCount);
            Console.WriteLine("NewMessageReceived:" + value);
        }

        static void webscoketServer_NewDataReceived(WebSocketSession session, byte[] value)
        {
            Console.WriteLine("NewDataReceived:" + value);
        }

        static void webscoketServer_NewSessionConnected(WebSocketSession session)
        {
            Console.WriteLine("NewSessionConnected");
        }

        static void webscoketServer_SessionClosed(WebSocketSession session, CloseReason value)
        {
            Console.WriteLine("SessionClosed");
        }

    }
}



//Name = serverName,
//MaxConnectionNumber = 10000, //最大允许的客户端连接数目，默认为100。
//Mode = SocketMode.Tcp,
//Port = port, //服务器监听的端口。
//ClearIdleSession = false,   //true或者false， 是否清除空闲会话，默认为false。
//ClearIdleSessionInterval = 120,//清除空闲会话的时间间隔，默认为120，单位为秒。
//ListenBacklog = 10,
//ReceiveBufferSize = 64 * 1024, //用于接收数据的缓冲区大小，默认为2048。
//SendBufferSize = 64 * 1024,   //用户发送数据的缓冲区大小，默认为2048。
//KeepAliveInterval = 1,     //keep alive消息发送时间间隔。单位为秒。
//KeepAliveTime = 60,    //keep alive失败重试的时间间隔。单位为秒。
//SyncSend = false


//name: 服务器实例的名称;
//serverType: 服务器实例的类型的完整名称;
//serverTypeName: 所选用的服务器类型在 serverTypes 节点的名字，配置节点 serverTypes 用于定义所有可用的服务器类型，我们将在后面再做详细介绍;
//ip: 服务器监听的ip地址。你可以设置具体的地址，也可以设置为下面的值 Any - 所有的IPv4地址 IPv6Any - 所有的IPv6地址
//port: 服务器监听的端口;
//listenBacklog: 监听队列的大小;
//mode: Socket服务器运行的模式, Tcp (默认) 或者 Udp;
//disabled: 服务器实例是否禁用了;
//startupOrder: 服务器实例启动顺序, bootstrap 将按照此值的顺序来启动多个服务器实例;
//sendTimeOut: 发送数据超时时间;
//sendingQueueSize: 发送队列最大长度, 默认值为5;
//maxConnectionNumber: 可允许连接的最大连接数;
//receiveBufferSize: 接收缓冲区大小;
//sendBufferSize: 发送缓冲区大小;
//syncSend: 是否启用同步发送模式, 默认值: false;
//logCommand: 是否记录命令执行的记录;
//logBasicSessionActivity: 是否记录session的基本活动，如连接和断开;
//clearIdleSession: true 或 false, 是否定时清空空闲会话，默认值是 false;
//clearIdleSessionInterval: 清空空闲会话的时间间隔, 默认值是120, 单位为秒;
//idleSessionTimeOut: 会话空闲超时时间; 当此会话空闲时间超过此值，同时clearIdleSession被配置成true时，此会话将会被关闭; 默认值为300，单位为秒;
//security: Empty, Tls, Ssl3. Socket服务器所采用的传输层加密协议，默认值为空;
//maxRequestLength: 最大允许的请求长度，默认值为1024;
//textEncoding: 文本的默认编码，默认值是 ASCII;
//defaultCulture: 此服务器实例的默认 thread culture, 只在.Net 4.5中可用而且在隔离级别为 'None' 时无效;
//disableSessionSnapshot: 是否禁用会话快照, 默认值为 false.
//sessionSnapshotInterval: 会话快照时间间隔, 默认值是 5, 单位为秒;
//keepAliveTime: 网络连接正常情况下的keep alive数据的发送间隔, 默认值为 600, 单位为秒;
//keepAliveInterval: Keep alive失败之后, keep alive探测包的发送间隔，默认值为 60, 单位为秒;
//certificate: 这各节点用于定义用于此服务器实例的X509Certificate证书的信息